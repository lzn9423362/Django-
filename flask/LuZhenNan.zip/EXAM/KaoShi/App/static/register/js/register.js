

$(function(){
	
	//使用Ajax进行注册

	
})
