 
$(function(){

     //使用Ajax进行登录


})
